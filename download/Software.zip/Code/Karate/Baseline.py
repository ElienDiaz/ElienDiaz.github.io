import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import random

def Baseline():
    G_original = nx.karate_club_graph()

    Burget = [1,0,1,0,1,0,1,0,1,0]
    Danger = list(np.random.rand(G_original.number_of_nodes()))

    p = 0.5

    def Reduce(x, x0):
        if (x == (x0)):
            return 1.0
        elif (x == (x0+1)):
            return 0.8
        elif (x == (x0+2)):
            return 0.6
        elif (x == (x0+3)):
            return 0.4
        elif (x == (x0+4)):
            return 0.2
        else:
            return 0

    ResultI = [[],[],[],[],[],[],[],[],[],[]]
    ResultWeight = [[],[],[],[],[],[],[],[],[],[]]

    for average in range(100):
        G = nx.Graph()
        for t in range(10):
            for NodeNow in G_original.nodes():
                G.add_node((t*G_original.number_of_nodes())+NodeNow)
                if (t > 0):
                    G.add_edge(((t-1)*G_original.number_of_nodes())+NodeNow, (t*G_original.number_of_nodes())+NodeNow)
            for EdgeNow in G_original.edges():
                if (random.random() < 0.1):
                    G.add_edge((t*G_original.number_of_nodes())+EdgeNow[0],(t*G_original.number_of_nodes())+EdgeNow[1])

        ImmunizationDictionary = {}

        for NodeNow in G.nodes():
            G.nodes[NodeNow]['state'] = 'S'

        G.nodes[0]['state'] = 'I'

        for t in range(10):
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'I'):
                    for NodeLinked in G.neighbors(NodeNow):
                        if (G.nodes[NodeLinked]['state'] == 'S'):
                            if ((NodeLinked%G_original.number_of_nodes()) in ImmunizationDictionary.keys()):
                                probability = (1.0-Reduce(t,ImmunizationDictionary[NodeLinked%G_original.number_of_nodes()]))*p
                                if (random.random() < probability):
                                    G.nodes[NodeLinked]['state'] = 'I'
                            else:
                                probability = p
                                if (random.random() < probability):
                                    G.nodes[NodeLinked]['state'] = 'I'
                                    
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'I'):
                    if (t < 9):
                        G.nodes[NodeNow+G_original.number_of_nodes()]['state'] = 'I'
        
        for t in range(10):
            counter = 0
            weight = 0
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'I'):
                    counter = counter + 1
                    weight = weight + Danger[NodeNow%G_original.number_of_nodes()]
            ResultI[t].append(counter)
            ResultWeight[t].append(weight)

    ResultI = np.array(ResultI)
    ResultWeight = np.array(ResultWeight)
    print (np.mean(ResultI,axis=1))
    print (np.mean(ResultWeight,axis=1))
    return np.mean(ResultI,axis=1),np.mean(ResultWeight,axis=1)
