from Baseline import Baseline
from Random import RandomExp
from Degree import Degree
from VaccineGreedy import VaccineGreedy
import matplotlib.pyplot as plt

print("Running Baseline")
I1, IW1 = Baseline()
print("Running Degree")
I2, IW2 = Degree()
print("Running Random")
I3, IW3 = RandomExp()
print("Running Greedy")
I4, IW4 = VaccineGreedy()

t = range(10)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, I1, 'b', alpha=0.5, lw=2, label='Baseline')
ax.plot(t, I2, 'g', alpha=0.5, lw=2, label='Degree-Based Vaccination')
ax.plot(t, I3, 'k', alpha=0.5, lw=2, label='Random Vaccination')
ax.plot(t, I4, 'm', alpha=0.5, lw=2, label='Greedy Algorithm-Based Vaccination')
ax.set_xlabel('Time')
ax.set_ylabel('Average count of infected people')
# ax.set_ylim(0, 1)
ax.yaxis.set_tick_params(length=0)
ax.xaxis.set_tick_params(length=0)
ax.grid(b=True, which='major', c='w', lw=2, ls='-')
for spine in ('top', 'right', 'bottom', 'left'):
    ax.spines[spine].set_visible(False)
legend = ax.legend()
legend.get_frame().set_alpha(0.5)
plt.show()

t = range(10)
fig = plt.figure(facecolor='w')
ax = fig.add_subplot(111, facecolor='#dddddd', axisbelow=True)
ax.plot(t, IW1, 'b', alpha=0.5, lw=2, label='Baseline')
ax.plot(t, IW2, 'g', alpha=0.5, lw=2, label='Degree-Based Vaccination')
ax.plot(t, IW3, 'k', alpha=0.5, lw=2, label='Random Vaccination')
ax.plot(t, IW4, 'm', alpha=0.5, lw=2, label='Greedy Algorithm-Based Vaccination')
ax.set_xlabel('Time')
ax.set_ylabel('Average weighted count of infected people')
# ax.set_ylim(0, 1)
ax.yaxis.set_tick_params(length=0)
ax.xaxis.set_tick_params(length=0)
ax.grid(b=True, which='major', c='w', lw=2, ls='-')
for spine in ('top', 'right', 'bottom', 'left'):
    ax.spines[spine].set_visible(False)
legend = ax.legend()
legend.get_frame().set_alpha(0.5)
plt.show()
