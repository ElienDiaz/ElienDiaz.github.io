Here, each folder contains the experiment code on on specific graph. For each graph, there exist 5 python code file that represents our VaccineGreedy algorithm results as well as the 4 baseline code file that we will compar with:
VaccineGreedy.py: The greedy algoirthm that we proposed
Baseline.py: We are not distributing the vaccines.
Random.py: We are distributing the vaccines by randomly selecting the nodes.
Degree.py: We are distributing the vaccines by sorting the degree of the nodes and distributing them.
PlotGraphs.py: The code that do all simulations at the same time and generate the result performance curve.
Each python contains a function of the same name that do simulation according to the distribution rules, and run plot.py can generate the plots at the same time.