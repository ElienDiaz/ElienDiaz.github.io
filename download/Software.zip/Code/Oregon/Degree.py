import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import random
import math

def Degree():
    G_original = nx.Graph()
    G_original = nx.read_edgelist('./Dataset/oregon1_010331.txt', nodetype=int)

    mapping = {}
    counter = 0
    for tempNodeName in G_original.nodes:
        mapping[tempNodeName] = counter
        counter = counter + 1
    G_original = nx.relabel_nodes(G_original, mapping)

    Burget = [20,20,20,20,20,20,20,20,20,20]
    Danger = list(np.random.rand(G_original.number_of_nodes()))

    p = 0.5

    def Reduce(x, x0):
        if (x == (x0)):
            return 1.0
        elif (x == (x0+1)):
            return 0.8
        elif (x == (x0+2)):
            return 0.6
        elif (x == (x0+3)):
            return 0.4
        elif (x == (x0+4)):
            return 0.2
        else:
            return 0

    ResultI = [[],[],[],[],[],[],[],[],[],[]]
    ResultWeight = [[],[],[],[],[],[],[],[],[],[]]

    for average in range(100):
        G = nx.Graph()
        for t in range(10):
            for NodeNow in G_original.nodes():
                G.add_node((t*G_original.number_of_nodes())+NodeNow)
                if (t > 0):
                    G.add_edge(((t-1)*G_original.number_of_nodes())+NodeNow, (t*G_original.number_of_nodes())+NodeNow)
            for EdgeNow in G_original.edges():
                if (random.random() < 0.1):
                    G.add_edge((t*G_original.number_of_nodes())+EdgeNow[0],(t*G_original.number_of_nodes())+EdgeNow[1])

        ImmunizationDictionary = {}

        for NodeNow in G.nodes():
            G.nodes[NodeNow]['state'] = 'S'

        G.nodes[0]['state'] = 'I'

        for t in range(10):

            VaccineNowList = []
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'S'):
                    NeighborCount = 0
                    for NodeLinked in G.neighbors(NodeNow):
                        NeighborCount = NeighborCount + 1
                    if ((NodeNow%G_original.number_of_nodes()) in ImmunizationDictionary.keys()):
                        if (Reduce(t,ImmunizationDictionary[NodeNow%G_original.number_of_nodes()]) < 0.4):
                            VaccineNowList.append(NeighborCount)
                        else:
                            VaccineNowList.append(0)
                    else:
                        VaccineNowList.append(NeighborCount)              
                else:
                    VaccineNowList.append(0)

            InjectCounter = 0
            while (InjectCounter < Burget[t]):
                Inject = VaccineNowList.index(max(VaccineNowList))
                VaccineNowList[Inject] = 0
                ImmunizationDictionary[Inject] = t
                InjectCounter = InjectCounter + 1
                    
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'I'):
                    for NodeLinked in G.neighbors(NodeNow):
                        if (G.nodes[NodeLinked]['state'] == 'S'):
                            if ((NodeLinked%G_original.number_of_nodes()) in ImmunizationDictionary.keys()):
                                probability = (1.0-Reduce(t,ImmunizationDictionary[NodeLinked%G_original.number_of_nodes()]))*p
                                if (random.random() < probability):
                                    G.nodes[NodeLinked]['state'] = 'I'
                            else:
                                probability = p
                                if (random.random() < probability):
                                    G.nodes[NodeLinked]['state'] = 'I'
                                    
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'I'):
                    if (t < 9):
                        G.nodes[NodeNow+G_original.number_of_nodes()]['state'] = 'I'
        
        for t in range(10):
            counter = 0
            weight = 0
            for NodeNow in range((t*G_original.number_of_nodes()),((t+1)*G_original.number_of_nodes())):
                if (G.nodes[NodeNow]['state'] == 'I'):
                    counter = counter + 1
                    weight = weight + Danger[NodeNow%G_original.number_of_nodes()]
            ResultI[t].append(counter)
            ResultWeight[t].append(weight)

    ResultI = np.array(ResultI)
    ResultWeight = np.array(ResultWeight)
    ResultI = np.mean(ResultI,axis=1)
    ResultWeight = np.mean(ResultWeight,axis=1)
    return ResultI, ResultWeight
